Supporting material for the paper  "On the Geometry of Discrete Exponential Families with Application to Exponential Random Graph Models" by Stephen E. Fienberg, Alessandro Rinaldo and Yi Zhou.




FIGURES
=======
The directory `figures' contains 11 figures of the entropy function over the natural and mean-value space for a variety of ERG models with 2-dimensional sufficient statistics on 7 and 9 nodes. The name of each file is also a description of the type of plot.



MOVIES
======
The directory `movies' contains 4 .avi animations demonstrating the relationship between natural and mean-value parametrization and the role of the normal fan. These files were obtained by pasting plots obtained from the MATLAB GUI interface.


We provide the following codes.

C++ MPI code
============
The file main.cpp in the directory `code' contains the source code for the program for complete enumeration of all undirected graphs on n nodes and for counting the number of edges, triangles, k-stars and alternating k-stars.


MATLAB GUIs
===========
The directory `MATLAB_GUIs' contains the MATLAB code (and the corresponding .mat files) for visualizing the entropy functions over the mean and natural parameter spaces for various ERG models on 5, 6, 7, 8 and 9 nodes.

We have two separate implementations of the GUI, one for smaller ERG models on 5, 6 and 7 nodes, and the other for ERG models on 8 and 9 nodes. 

For graphs on 5, 6 and 7 nodes, the GUI displays the entropy plots for the following 2-dimensional sufficient statistics:
- edges vs triangles- edges vs 2-stars- edge vs alternating k-stars (with lambda = 2)The natural parameter corresponding to the number of edges is theta, while the second parameter is tau.

 
For graphs on 8 and 9 nodes, the GUI displays the entropy plots for the following 2-dimensional sufficient statistics:
- edges vs triangles- edge vs 2-stars (with lambda = 2)The natural parameter corresponding to the number of edges is theta, while the second parameter is tau.


To start the GUI, type in MATLAB `maingui' or `maingui2', depending whether you are interested in models on 5, 6 and 7 nodes, or in models on 8 and 9 nodes, respectively.

The GUI is pretty much self-explanatory. Before loading a dataset, you must select the type of sufficient statistics for the ERG model from the combo menu. Then, click on the `Load data' button and select the .mat file corresponding to the graph you want to investigate.  The plot of the entropy function over the natural parameter space (in the default jet colormap) should appear on the left, along with the dashed lines outlining the normal cones of the corresponding convex support. If you click on the button 'Select point' you will be able to select a point in the natural parameter space. As soon as you select a point, the right plot will display the support and convex support of the distribution of the sufficient statistics. The red star-like point indicates the mean value parameter corresponding to the natural parameter selected on the first plot. The color shading of the points in the support represents the probability mass, with darker colors corresponding to higher values of the probability mass function. The button `Copy out' will open in a different windows a 3-dimensional figure of the entropy plot for the natural parameter space.