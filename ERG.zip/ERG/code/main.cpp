/*************************************************************************************

Note:
	1. to compile the file, use command "mpicxx main.cpp -o mainapp".
	2. to execute it, use command 
			"mpiexec -np 10 ./mainapp 5 -t 10" or
			"mpiexec -np 10 ./mainapp 5"
	   (1) "mpiexec -np 10" means you are gonna use 10 node processors.
	   (2) "mpiexec -np 10 ./mainapp 5 -t 10" is a try of the program, which enumerates
		   ten 5-node graphs. you can use it to estimate the time for enumerating all
		   5-node graphs.
	   (3) "mpiexec -np 10 ./mainapp 5" is to enumerate all 5-node graphs.


*************************************************************************************/


#define HAVE_NO_VARIABLE_RETURN_TYPE_SUPPORT
#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <time.h>

#ifndef max
#define max(a,b) (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif

/*
// pseudo 64-bit integer in 32-bit machine
typedef __int64 mylongint;
char *strformat = "%I64u";
*/

/*
// integer in 32-bit machine
typedef int mylongint;
char *strformat = "%d";
*/


// integer in 64-bit machine
typedef long long mylongint;
char *strformat = "%ld";




class IVector{
public:
	IVector() { data=NULL; dim = 0; };
	IVector(int dim) { this->dim = dim; this->data = new int[dim]; };
	~IVector() { delete[] data; data = NULL; };

	int& operator[] (int i) const { assert(i<dim && i>=0); return data[i]; };
	int size() const { return dim; };
	
private:
	int dim;
	int *data;
};

class IMatrix{
public:
	IMatrix() { data = NULL; nrow = 0; ncol = 0; };
	IMatrix(int nrow, int ncol) { this->nrow = nrow; this->ncol = ncol; this->data = new int[nrow*ncol]; };
	~IMatrix() { if (data) { delete[] data; data = NULL; }};
	
	int *GetData() { return data; };
	int& GetAt(int i, int j) { assert(i>=0 && i<nrow); assert(j>=0 && j<ncol); return data[i*ncol+j]; };
	
	int nrow;
	int ncol;

private:
	int *data;
};

class LMatrix{
public:
	LMatrix() { data = NULL; nrow = 0; ncol = 0; };
	LMatrix(int nrow, int ncol) { this->nrow = nrow; this->ncol = ncol; this->data = new mylongint[nrow*ncol]; };
	~LMatrix() { if (data) { delete[] data; data = NULL; }};
	
	mylongint& GetAt(int i, int j) { assert(i>=0 && i<nrow); assert(j>=0 && j<ncol); return data[i*ncol+j]; };
	
	int nrow;
	int ncol;
	
private:
	mylongint *data;	
};

int n_proc;
int my_rank;


#define GETAT(data, j)  ((data&((mylongint)1<<j))>>j)
#define SETAT(data, j, b) {if (b) {data = (data|((mylongint)1<<j));} else {data = (data&(~((mylongint)1<<j)));}}


/**************************************************************************

A SUBROUTINE TO COUNT THE NUMBER OF EDGES, NUMBER OF TRIANGLES, AND NUMBER 
OF 2-STARS IN THE GRAPH.

**************************************************************************/
void statistics(int nNode, mylongint g, int &nEdge, int &nTri, int &nStar2)
{
	int i,j,k;

	// number of edges
	nEdge = 0;
	for (i=0; i<nNode*(nNode-1)/2; i++)
		if (GETAT(g,i)) nEdge ++;

	// number of triangles and stars
	nTri = nStar2 = 0;
	for (i=0; i<nNode; i++)
		for (j=i+1; j<nNode; j++)
			for (k=j+1; k<nNode; k++)
			{
				bool ij = GETAT(g,j*(j-1)/2+i);
				bool ik = GETAT(g,k*(k-1)/2+i);
				bool jk = GETAT(g,k*(k-1)/2+j);
				if (ij && ik && jk) nTri++;
				if (ij && ik) nStar2 ++;
				if (ij && jk) nStar2 ++;
				if (ik && jk) nStar2 ++;
			}	
}


/**************************************************************************

A SUBROUTINE TO GET THE ADJACENT MATRIX OF THE GRAPH.

**************************************************************************/
void GetAdjacentMat(int nNode, mylongint g, IMatrix& adjmat)
{
	assert(adjmat.ncol == nNode);
	assert(adjmat.nrow == nNode);
	
	int i, j;
	for (i=0; i<nNode; i++)
	{
		adjmat.GetAt(i,i) = 0;
		for (j=i+1; j<nNode; j++)
			adjmat.GetAt(i,j) = adjmat.GetAt(j,i) = GETAT(g,j*(j-1)/2+i);
	}

/*
	// debug info (in case you want to check the adjacent matrix)
	FILE * fp = fopen("adjmat.txt", "wt");
	if (fp)
	{
		for (i=0; i<adjmat.nrow; i++)
		{
			for (j=0; j<adjmat.ncol; j++)
				fprintf(fp, "%d ", adjmat.GetAt(i,j));
			fprintf(fp, "\n");
		}
		fclose(fp);
	}
*/
}


/**************************************************************************

A SUBROUTINE TO COMPUTE THE COMBINATION NUMBER OF N CHOOSE K.

**************************************************************************/
int nchoosek(int n, int k)
{
	assert((n>=k) && (k>=0));

	int value, i;
	if (k==0) 
	{
		value = 0;
	}
	else
	{
		value = 1;
		for (i=0; i<k; i++)
			value *= n-i;
		for (i=0; i<k; i++)
			value /= k-i;
	}

	return value;
}

/**************************************************************************

A SUBROUTINE TO COUNT THE NUMBER OF K-STARS (K>=2) IN THE GRAPH.

**************************************************************************/
void CountKStars(int nNode, mylongint g, IVector& kstars)
{
	assert(kstars.size() == nNode);
	
	IMatrix adjmat(nNode, nNode);
	GetAdjacentMat(nNode, g, adjmat);
	
	IVector degrees(nNode);
	int i, j;
	for (i=0; i<nNode; i++)
	{
		degrees[i] = 0;
		for (j=0; j<nNode; j++)
			degrees[i] += adjmat.GetAt(i,j);
	}
	
	for (i=0; i<nNode; i++)
		kstars[i] = 0;
	for (i=0; i<nNode; i++)
		for (j=2; j<=degrees[i]; j++)
		{
			kstars[j] += nchoosek(degrees[i], j);
		}
}

/**************************************************************************

A SUBROUTINE TO COUNT THE ALTERNATING K-STAR STATISTICS GIVEN LAMBDA.

**************************************************************************/
double CountKStars(int nNode, mylongint g, double lambda)
{
	double res;
	if (lambda<=0)
		lambda = 2;

	IVector kstars(nNode);	
	IMatrix adjmat(nNode, nNode);
	GetAdjacentMat(nNode, g, adjmat);
	
	IVector degrees(nNode);
	int i, j;
	for (i=0; i<nNode; i++)
	{
		degrees[i] = 0;
		for (j=0; j<nNode; j++)
			degrees[i] += adjmat.GetAt(i,j);
	}
	
	for (i=0; i<nNode; i++)
		kstars[i] = 0;
	for (i=0; i<nNode; i++)
		for (j=2; j<=degrees[i]; j++)
		{
			kstars[j] += nchoosek(degrees[i], j);
		}

	res = 0;
	for (i=2; i<nNode; i++)
		if (GETAT(i,0)==0)
			res += kstars[i] / pow(lambda,i-2);
		else
			res -= kstars[i] / pow(lambda,i-2);
	return res;
}

/**************************************************************************

A SUBROUTINE TO COUNT THE NUMBER OF EDGES IN THE GRAPH.

**************************************************************************/
int CountEdges(int nNode, mylongint g)
{
	int edges = 0;
	for (int i=0; i<nNode*(nNode-1)/2; i++)
		if (GETAT(g,i)) edges++;		

	return edges;
}

/**************************************************************************

A SUBROUTINE TO COUNT THEN NUMBER OF 2-STARS IN THE GRAPH.

**************************************************************************/
int Count2Stars(int nNode, mylongint g)
{
	int star2;
	int i,j,k;
	star2 = 0;
	for (i=0; i<nNode; i++)
		for (j=i+1; j<nNode; j++)
			for (k=j+1; k<nNode; k++)
			{
				bool ij = GETAT(g,j*(j-1)/2+i);
				bool ik = GETAT(g,k*(k-1)/2+i);
				bool jk = GETAT(g,k*(k-1)/2+j);
				if (ij && ik) star2++;
				if (ij && jk) star2++;
				if (ik && jk) star2++;
			}	
	
	return star2;
}


/**************************************************************************

A SUBROUTINE TO COUNT THE NUMBER OF TRIANGLES IN THE GRAPH.

**************************************************************************/
int CountTriangles(int nNode, mylongint g)
{
	int tri = 0;
	int i, j, k;
	for (i=0; i<nNode; i++)
		for (j=i+1; j<nNode; j++)
			for (k=j+1; k<nNode; k++)
			{
				bool ij = GETAT(g,j*(j-1)/2+i);
				bool ik = GETAT(g,k*(k-1)/2+i);
				bool jk = GETAT(g,k*(k-1)/2+j);
				if (ij && ik && jk) tri++;
			}	
			
	return tri;
}


/**************************************************************************

A SUBROUTINE TO ENUMBERATE ALL POSSIBLE GRAPHS WITH A FIXED NUMBER OF
NODES; AND SAVE THE RESULTS AS TWO COUNTING MATRICES: 1. ONE HAS THE EDGE 
NUMBER IN THE ROW AND THE TRIANGLE NUMBER IN THE COLUMN; 2. THE OTHER HAS
THE EDGE NUMEBR IN THE ROW AND THE 2-STAR NUMBER IN THE COLUMN.

USE THIS FUNCTION IF YOU DON'T CONSIDER THE K-STARS BECAUSE IT SAVES A LOT
MEMORY.

**************************************************************************/
void enumerate(int nNode, int nProc, mylongint nBegin, mylongint nEnd)
{	
	int nEdge = nNode*(nNode-1) / 2;
	int nTri = nNode*(nNode-1)*(nNode-2) / 6;
	int nStar = nNode*(nNode-1)*(nNode-2) / 2;
	
	mylongint i, n;
	int j, k, m;
	n = mylongint( pow(2.0, nEdge) );
	
	assert( nBegin>=0 );
	assert( nBegin<=nEnd );
	assert( nEnd<=n-1 );

	LMatrix triMat(nEdge+1, nTri+1);
	LMatrix starMat(nEdge+1, nStar+1);
	for (j=0; j<starMat.nrow; j++)
		for (k=0; k<starMat.ncol; k++)
			starMat.GetAt(j,k) = 0;		
	for (j=0; j<triMat.nrow; j++)
		for (k=0; k<triMat.ncol; k++)
			triMat.GetAt(j,k) = 0;
			

	for (i=nBegin; i<=nEnd; i++)
	{		
		statistics(nNode, i, j, k, m);
		triMat.GetAt(j,k) = triMat.GetAt(j,k) + 1;
		starMat.GetAt(j,m) = starMat.GetAt(j,m) + 1;
	}

	// save the results
	char filename[128];
	sprintf(filename, "graph%02dprocess%02d.txt", nNode, nProc);
	FILE * fp = fopen(filename, "wt");
	if (fp)
	{
		fprintf(fp, strformat, nBegin);
		fprintf(fp, "\t");
		fprintf(fp, strformat, nEnd);
		fprintf(fp, "\n");
		fprintf(fp, "edge-triangle:\n");
		for (k=0; k<triMat.nrow; k++)
			for (j=0; j<triMat.ncol; j++)
				if ( triMat.GetAt(k,j)!=0 )
					fprintf(fp, "%d\t%d\t%d\n", k, j, triMat.GetAt(k,j));
				
				
		fprintf(fp, "edge-2star:\n");
		for (k=0; k<starMat.nrow; k++)
			for (j=0; j<starMat.ncol; j++)
				if ( starMat.GetAt(k,j)!=0 )
					fprintf(fp, "%d\t%d\t%d\n", k, j, starMat.GetAt(k,j));
				
		fclose(fp);
	}	
}


/**************************************************************************

A SUBROUTINE TO ENUMBERATE ALL POSSIBLE GRAPHS WITH A FIXED NUMBER OF
NODES; AND SAVE THE NUMBERS OF EDGES, THE NUMBERS OF TRIANGLES, AND THE 
NUMBERS OF ALTERNATING K-STARS.

**************************************************************************/
void enumerate2(int nNode, int nProc, mylongint nBegin, mylongint nEnd)
{
	char filename[128];
	FILE * fp;
	IVector kstars(nNode);
	int i;
	mylongint li;

	// count alternating k-stars
	sprintf(filename, "kstar%02dprocess%02d.txt", nNode, nProc);
	fp = fopen(filename, "wt");
	if (fp)
	{
		fprintf(fp, strformat, nBegin);
		fprintf(fp, "\t");
		fprintf(fp, strformat, nEnd);
		fprintf(fp, "\n");
		for (li=nBegin; li<=nEnd; li++)
			fprintf(fp, "%.6f\n", CountKStars(nNode, li, 2));
		fclose(fp);
	}

	// count edges
	sprintf(filename, "edge%02dprocess%02d.txt", nNode, nProc);
	fp = fopen(filename, "wt");
	if (fp)
	{
		fprintf(fp, strformat, nBegin);
		fprintf(fp, "\t");
		fprintf(fp, strformat, nEnd);
		fprintf(fp, "\n");
		//fprintf(fp, "%d %d\n", nBegin, nEnd);
		for (li=nBegin; li<=nEnd; li++)
			fprintf(fp, "%d\n", CountEdges(nNode, li));
		fclose(fp);
	}
	
	// count 2-stars
	sprintf(filename, "2star%02dprocess%02d.txt", nNode, nProc);
	fp = fopen(filename, "wt");
	if (fp)
	{
		fprintf(fp, strformat, nBegin);
		fprintf(fp, "\t");
		fprintf(fp, strformat, nEnd);
		fprintf(fp, "\n");		
		//fprintf(fp, "%d %d\n", nBegin, nEnd);
		for (li=nBegin; li<=nEnd; li++)
			fprintf(fp, "%d\n", Count2Stars(nNode, li));
		fclose(fp);
	}

	// count triangles
	sprintf(filename, "tri%02dprocess%02d.txt", nNode, nProc);
	fp = fopen(filename, "wt");
	if (fp)
	{
		fprintf(fp, strformat, nBegin);
		fprintf(fp, "\t");
		fprintf(fp, strformat, nEnd);
		fprintf(fp, "\n");		
		//fprintf(fp, "%d %d\n", nBegin, nEnd);
		for (li=nBegin; li<=nEnd; li++)
			fprintf(fp, "%d\n", CountTriangles(nNode, li));
		fclose(fp);
	}
	
}


/**************************************************************************

THE MAIN FUNCTION. 

**************************************************************************/
int main(int argc, char* argv[])
{
	if (argc<2)
	{
		printf("Usage:\tmain.exe  [number of nodes]  [option -t]  [number of try]\n\n");
		printf("Example:\tmain.exe  5\n");
		printf("----the above command will count all 5-node graphs.----\n\n");
		printf("Example:\tmain.exe  5  -t  10\n");
		printf("----the above command will count ten 5-node graphs.----\n");

		return 0;
	}

	int nNode, nEdge;
	nNode = atoi(argv[1]);
	nEdge = nNode*(nNode-1)/2;
	
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &n_proc);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
	
	mylongint nBegin, nEnd;
	nBegin = mylongint( ceil( pow(2.0, nEdge) / n_proc * my_rank ) );
	nEnd = mylongint( ceil( pow(2.0, nEdge) / n_proc * (my_rank+1) ) ) - 1;
	
	if (argc == 4)
	{
		if ( argv[2][1] == 't')
		{
			nBegin = mylongint(pow(2.0, nEdge)) - atoi(argv[3]) * (my_rank+1);
			nEnd = mylongint(pow(2.0, nEdge)) - atoi(argv[3]) * my_rank - 1;		
		}		
	}

	nBegin = max(nBegin, 0);
	nEnd = min(nEnd, mylongint(pow(2.0, nEdge)-1));
	nEnd = max(nEnd, nBegin);
	
	time_t sTime, endTime;

	time(&sTime);	


	// USE THIS ONE IF YOU DO NOT WANT TO CONSIDER THE ALTERNATING K-STARS 
	// BECAUSE IT SAVES A LOT OF MEMORY.
	enumerate(nNode, my_rank, nBegin, nEnd);

/*	
	// USE THIS ONE IF YOU WANT TO CONSIDER THE ALTENATING K-STARS.
	enumerate2(nNode, my_rank, nBegin, nEnd);
*/

	time(&endTime);
	printf("processor #%d/%d finished in %ld seconds.\n", my_rank, n_proc, endTime-sTime);	
	
	MPI_Finalize();	
	return 0;
}